insert into Usuario
	(id,nombre,contraseña,fecha)
    values
    ("Raul Rodriguez", "Qwerty123456"),
    ("Daniel Requena", "123456Qwerty"),
    (4,"David","holaMundo","09/04/2022");